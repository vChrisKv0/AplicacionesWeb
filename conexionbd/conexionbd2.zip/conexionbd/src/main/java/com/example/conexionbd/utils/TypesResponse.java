package com.example.conexionbd.utils;

public enum TypesResponse {
    SUCCESS,
    ERROR,
    WARNING
}