package com.example.conexionbd.turnos.model;

public class TurnosDTO {
}
